import { Link } from "react-router-dom"
import {
    Mail,
    MapPin,
    Phone,
} from "lucide-react"


import { siteConfig } from "../../config/site"
import { navigation } from "../../data/navigation"
import useLanguage from "../../hooks/useLanguage"

export default function Footer() {
    const { language, isArabic } = useLanguage()

    const navItems = navigation[language]

    const currentYear = new Date().getFullYear()

    return (
        <footer className="border-t border-slate-200 bg-slate-950 text-white dark:border-slate-800">

            <div className="container-site">

                {/* Main Footer */}
                <div className="grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-4 lg:gap-12 lg:py-16">

                    {/* Company */}
                    <div className="lg:col-span-1">

                        <Link
                            to="/"
                            className="inline-flex items-center"
                        >
                            <img
                                src={siteConfig.logo}
                                alt={
                                    isArabic
                                        ? "الرائدة للأدوية"
                                        : "AL-Raidah Pharmaceutical"
                                }
                                className="h-14 w-auto rounded-lg object-contain"
                            />
                        </Link>

                        <p className="mt-5 max-w-sm text-sm leading-7 text-slate-300">
                            {isArabic
                                ? "الرائدة للأدوية، نسعى إلى تقديم حلول دوائية موثوقة وفق أعلى معايير الجودة، مع الالتزام بالتطوير المستمر وخدمة المجتمع."
                                : "AL-Raidah Pharmaceutical is committed to providing reliable pharmaceutical solutions with high quality standards, continuous development, and social responsibility."}
                        </p>

                        {/* Social */}
                        <div className="mt-6 flex items-center gap-2">

                            <a
                                href="#"
                                aria-label="Facebook"
                                className="
                  flex
                  h-10
                  w-10
                  items-center
                  justify-center
                  rounded-full
                  border
                  border-slate-700
                  text-slate-300
                  transition-all
                  duration-300
                  hover:-translate-y-1
                  hover:border-primary
                  hover:bg-primary
                  hover:text-white
                "
                            >
                                <svg
                                    viewBox="0 0 24 24"
                                    className="h-[17px] w-[17px]"
                                    fill="currentColor"
                                    aria-hidden="true"
                                >
                                    <path d="M14 8h3V4.5c-.52-.07-1.74-.17-3.3-.17-3.27 0-5.51 2-5.51 5.7V13H4v4h4.19v7h4.02v-7h3.57l.57-4h-4.14v-2.56c0-1.16.32-1.94 1.79-1.94Z" />
                                </svg>
                            </a>

                            <a
                                href="#"
                                aria-label="Instagram"
                                className="
                  flex
                  h-10
                  w-10
                  items-center
                  justify-center
                  rounded-full
                  border
                  border-slate-700
                  text-slate-300
                  transition-all
                  duration-300
                  hover:-translate-y-1
                  hover:border-primary
                  hover:bg-primary
                  hover:text-white
                "
                            >
                                <svg
                                    viewBox="0 0 24 24"
                                    className="h-[17px] w-[17px]"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth="1.8"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    aria-hidden="true"
                                >
                                    <rect
                                        x="3"
                                        y="3"
                                        width="18"
                                        height="18"
                                        rx="5"
                                    />
                                    <circle
                                        cx="12"
                                        cy="12"
                                        r="4"
                                    />
                                    <circle
                                        cx="17.5"
                                        cy="6.5"
                                        r="1"
                                        fill="currentColor"
                                        stroke="none"
                                    />
                                </svg>
                            </a>

                            <a
                                href="#"
                                aria-label="LinkedIn"
                                className="
                  flex
                  h-10
                  w-10
                  items-center
                  justify-center
                  rounded-full
                  border
                  border-slate-700
                  text-slate-300
                  transition-all
                  duration-300
                  hover:-translate-y-1
                  hover:border-primary
                  hover:bg-primary
                  hover:text-white
                "
                            >
                                <svg
                                    viewBox="0 0 24 24"
                                    className="h-[17px] w-[17px]"
                                    fill="currentColor"
                                    aria-hidden="true"
                                >
                                    <path d="M6.5 8.25a2.25 2.25 0 1 0 0-4.5 2.25 2.25 0 0 0 0 4.5ZM4.5 10h4v10h-4V10Zm6 0h3.84v1.37h.05c.53-.95 1.83-1.95 3.77-1.95 4.03 0 4.77 2.65 4.77 6.1V20h-4v-3.98c0-.95-.02-2.17-1.32-2.17-1.32 0-1.52 1.03-1.52 2.1V20h-4V10Z" />
                                </svg>
                            </a>

                        </div>
                    </div>

                    {/* Navigation */}
                    <div>
                        <h3 className="text-base font-bold">
                            {isArabic
                                ? "روابط مهمة"
                                : "Quick Links"}
                        </h3>

                        <div className="mt-5 flex flex-col gap-3">
                            {navItems.slice(0, 6).map((item) => (
                                <Link
                                    key={item.path}
                                    to={item.path}
                                    className="
                    w-fit
                    text-sm
                    text-slate-300
                    transition-colors
                    duration-300
                    hover:text-primary
                  "
                                >
                                    {item.label}
                                </Link>
                            ))}
                        </div>
                    </div>

                    {/* Services */}
                    <div>
                        <h3 className="text-base font-bold">
                            {isArabic
                                ? "اكتشف الرائدة"
                                : "Discover AL-Raidah"}
                        </h3>

                        <div className="mt-5 flex flex-col gap-3">

                            <Link
                                to="/products"
                                className="text-sm text-slate-300 transition-colors hover:text-primary"
                            >
                                {isArabic
                                    ? "منتجاتنا"
                                    : "Our Products"}
                            </Link>

                            <Link
                                to="/training"
                                className="text-sm text-slate-300 transition-colors hover:text-primary"
                            >
                                {isArabic
                                    ? "التدريب المستمر"
                                    : "Continuous Training"}
                            </Link>

                            <Link
                                to="/social-responsibility"
                                className="text-sm text-slate-300 transition-colors hover:text-primary"
                            >
                                {isArabic
                                    ? "المسؤولية الاجتماعية"
                                    : "Social Responsibility"}
                            </Link>

                            <Link
                                to="/production-knowledge"
                                className="text-sm text-slate-300 transition-colors hover:text-primary"
                            >
                                {isArabic
                                    ? "معرفة الإنتاج"
                                    : "Production Knowledge"}
                            </Link>

                            <Link
                                to="/news"
                                className="text-sm text-slate-300 transition-colors hover:text-primary"
                            >
                                {isArabic
                                    ? "آخر الأخبار"
                                    : "Latest News"}
                            </Link>

                        </div>
                    </div>

                    {/* Contact */}
                    <div>
                        <h3 className="text-base font-bold">
                            {isArabic
                                ? "تواصل معنا"
                                : "Contact Us"}
                        </h3>

                        <div className="mt-5 flex flex-col gap-5">

                            <div className="flex items-start gap-3">
                                <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                                    <MapPin size={17} />
                                </span>

                                <p className="text-sm leading-6 text-slate-300">
                                    {isArabic
                                        ? "اليمن"
                                        : "Yemen"}
                                </p>
                            </div>

                            <div className="flex items-center gap-3">
                                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                                    <Phone size={17} />
                                </span>

                                <a
                                    href="tel:+967"
                                    className="text-sm text-slate-300 transition-colors hover:text-primary"
                                >
                                    +967
                                </a>
                            </div>

                            <div className="flex items-center gap-3">
                                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                                    <Mail size={17} />
                                </span>

                                <a
                                    href="mailto:info@alraidah.com"
                                    className="break-all text-sm text-slate-300 transition-colors hover:text-primary"
                                >
                                    info@alraidah.com
                                </a>
                            </div>

                        </div>
                    </div>

                </div>

                {/* Bottom */}
                <div className="flex flex-col gap-3 border-t border-slate-800 py-6 text-sm text-slate-400 md:flex-row md:items-center md:justify-between">

                    <p>
                        © {currentYear}{" "}
                        {isArabic
                            ? "الرائدة للأدوية"
                            : "AL-Raidah Pharmaceutical"}
                        .{" "}
                        {isArabic
                            ? "جميع الحقوق محفوظة."
                            : "All rights reserved."}
                    </p>

                    <p>
                        {isArabic
                            ? "الجودة • الثقة • التطوير"
                            : "Quality • Trust • Development"}
                    </p>

                </div>

            </div>
        </footer>
    )
}