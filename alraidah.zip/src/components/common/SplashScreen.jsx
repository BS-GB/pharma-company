import { useEffect, useState } from "react"
import { siteConfig } from "../../config/site"
import useLanguage from "../../hooks/useLanguage"

export default function SplashScreen() {
    const { isArabic } = useLanguage()

    const [visible, setVisible] = useState(true)
    const [closing, setClosing] = useState(false)

    useEffect(() => {
        const hasSeenSplash = sessionStorage.getItem(
            "alraidah-splash-seen"
        )

        if (hasSeenSplash) {
            setVisible(false)
            return
        }

        const closeTimer = setTimeout(() => {
            setClosing(true)
        }, 2800)

        const removeTimer = setTimeout(() => {
            sessionStorage.setItem(
                "alraidah-splash-seen",
                "true"
            )

            setVisible(false)
        }, 3800)

        return () => {
            clearTimeout(closeTimer)
            clearTimeout(removeTimer)
        }
    }, [])

    if (!visible) {
        return null
    }

    return (
        <div
            className={`raidah-splash ${closing ? "raidah-splash--closing" : ""
                }`}
            dir={isArabic ? "rtl" : "ltr"}
            aria-label={
                isArabic
                    ? "الرائدة للصناعات الدوائية"
                    : "AL-Raidah Pharmaceutical Industries"
            }
        >
            {/* =========================================
                Background Layers
            ========================================= */}

            <div className="raidah-splash__background">

                {/* نبضات متعددة الطبقات */}
                <span className="raidah-splash__pulse raidah-splash__pulse--1" />
                <span className="raidah-splash__pulse raidah-splash__pulse--2" />
                <span className="raidah-splash__pulse raidah-splash__pulse--3" />
                <span className="raidah-splash__pulse raidah-splash__pulse--4" />

                {/* أشكال هندسية ناعمة */}
                <span className="raidah-splash__shape raidah-splash__shape--circle-lg" />
                <span className="raidah-splash__shape raidah-splash__shape--circle-sm" />
                <span className="raidah-splash__shape raidah-splash__shape--ring-top" />
                <span className="raidah-splash__shape raidah-splash__shape--ring-bottom" />
                <span className="raidah-splash__shape raidah-splash__shape--dots" />

                {/* أشكال في الزوايا */}
                <span className="raidah-splash__corner raidah-splash__corner--tl" />
                <span className="raidah-splash__corner raidah-splash__corner--tr" />
                <span className="raidah-splash__corner raidah-splash__corner--bl" />
                <span className="raidah-splash__corner raidah-splash__corner--br" />

            </div>


            {/* =========================================
                Main Center
            ========================================= */}

            <div className="raidah-splash__center">

                {/* Logo */}
                <div className="raidah-splash__logo-frame">

                    <span className="raidah-splash__logo-ring raidah-splash__logo-ring--outer" />
                    <span className="raidah-splash__logo-ring raidah-splash__logo-ring--inner" />

                    <div className="raidah-splash__logo">

                        <img
                            src={siteConfig.logo}
                            alt={
                                isArabic
                                    ? "شعار الرائدة"
                                    : "AL-Raidah Logo"
                            }
                        />

                    </div>

                </div>


                {/* Brand Name */}
                <div className="raidah-splash__brand">

                    <div className="raidah-splash__brand-name">
                        {isArabic
                            ? "الرائدة"
                            : "AL-Raidah"}
                    </div>


                    <div className="raidah-splash__brand-line">
                        <span />
                        <span />
                    </div>


                    <div className="raidah-splash__brand-subtitle">
                        {isArabic
                            ? "للصناعات الدوائية"
                            : "Pharmaceutical Industries"}
                    </div>

                </div>


                {/* Statement */}
                <div className="raidah-splash__statement">
                    <p>
                        {isArabic
                            ? "جودة تُبنى عليها الثقة"
                            : "Quality that builds trust"}
                    </p>
                </div>

            </div>


            {/* =========================================
                Bottom Loading
            ========================================= */}

            <div className="raidah-splash__loading">
                <div className="raidah-splash__loading-track">
                    <div />
                </div>
            </div>

        </div>
    )
}